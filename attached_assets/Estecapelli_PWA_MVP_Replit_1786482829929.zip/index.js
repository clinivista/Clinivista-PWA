/*
  ESTECAPELLI · PWA de preevaluación capilar (MVP Replit)
  -------------------------------------------------------
  Un solo archivo. Sin dependencias.

  Cómo ejecutar en Replit:
  1. Crea un Repl Node.js.
  2. Pega este archivo como index.js.
  3. En Secrets agrega ADMIN_PASSWORD con una clave fuerte.
  4. Ejecuta: node index.js

  Para el panel del equipo: /?admin=1
  Para pacientes: usa un enlace generado desde el panel o /?patient=1

  Este MVP es un embudo comercial de preevaluación. No diagnostica, no calcula
  injertos y no reemplaza una consulta médica. Para producción se requiere
  revisión legal, almacenamiento clínico apropiado, controles de seguridad,
  acuerdos de tratamiento de datos e integración con la ficha clínica.
*/

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = Number(process.env.PORT || 3000);
const DATA_FILE = path.join(__dirname, 'estecapelli-data.json');
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'demo-estecapelli';
const IS_DEMO_PASSWORD = !process.env.ADMIN_PASSWORD;
const sessions = new Map();

function uid(bytes = 12) { return crypto.randomBytes(bytes).toString('hex'); }
function now() { return new Date().toISOString(); }
function readDB() {
  if (!fs.existsSync(DATA_FILE)) {
    const seeded = {
      leads: [
        { id: 'demo-1', token: uid(), createdAt: now(), updatedAt: now(), name: 'Camila R. (demo)', phone: '+56911111111', age: '34', city: 'Santiago', status: 'listo', consent: true, photoCount: 5, photos: [], hairLossTime: '3 años', previousTreatment: 'Minoxidil tópico', notes: '', norwood: '', demo: true },
        { id: 'demo-2', token: uid(), createdAt: now(), updatedAt: now(), name: 'Matías P. (demo)', phone: '+56922222222', age: '41', city: 'Las Condes', status: 'incompleto', consent: true, photoCount: 3, photos: [], hairLossTime: '5 años', previousTreatment: 'Ninguno', notes: 'Solicitar fotografía de zona donante.', norwood: '', demo: true },
        { id: 'demo-3', token: uid(), createdAt: now(), updatedAt: now(), name: 'Daniel C. (demo)', phone: '+56933333333', age: '37', city: 'Providencia', status: 'contactar', consent: true, photoCount: 5, photos: [], hairLossTime: '2 años', previousTreatment: 'Finasteride previo', notes: 'Llamar para coordinar consulta.', norwood: 'III-V', demo: true }
      ]
    };
    writeDB(seeded);
    return seeded;
  }
  try { return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')); }
  catch { return { leads: [] }; }
}
function writeDB(data) {
  const temp = DATA_FILE + '.tmp';
  fs.writeFileSync(temp, JSON.stringify(data, null, 2), 'utf8');
  fs.renameSync(temp, DATA_FILE);
}
function json(res, status, data) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(data));
}
function html(res) {
  res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(APP_HTML);
}
function parseBody(req, maxBytes = 14 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    let data = '';
    req.on('data', chunk => {
      data += chunk;
      if (Buffer.byteLength(data) > maxBytes) { reject(new Error('El archivo supera el límite permitido.')); req.destroy(); }
    });
    req.on('end', () => { try { resolve(data ? JSON.parse(data) : {}); } catch { reject(new Error('Solicitud inválida.')); } });
    req.on('error', reject);
  });
}
function cookies(req) {
  return (req.headers.cookie || '').split(';').reduce((acc, item) => {
    const i = item.indexOf('='); if (i > -1) acc[item.slice(0, i).trim()] = decodeURIComponent(item.slice(i + 1).trim()); return acc;
  }, {});
}
function authorized(req) {
  const token = cookies(req).estecapelli_session;
  const session = token && sessions.get(token);
  return Boolean(session && session.expiresAt > Date.now());
}
function requireAuth(req, res) { if (!authorized(req)) { json(res, 401, { error: 'Sesión requerida.' }); return false; } return true; }
function clean(value, max = 500) { return String(value || '').trim().replace(/[<>]/g, '').slice(0, max); }
function phone(value) { return clean(value, 30).replace(/[^+\d]/g, ''); }
function leadSummary(lead) {
  const { photos, ...safe } = lead;
  return { ...safe, photoCount: Array.isArray(photos) ? photos.length : (lead.photoCount || 0) };
}
function validPhoto(photo) {
  return photo && typeof photo === 'object' && typeof photo.key === 'string' && typeof photo.dataUrl === 'string' &&
    /^data:image\/(jpeg|jpg|png|webp);base64,/.test(photo.dataUrl) && photo.dataUrl.length < 2_500_000;
}
function normalizePhotos(photos) {
  const keys = new Set();
  return (Array.isArray(photos) ? photos : []).filter(validPhoto).filter(p => {
    if (keys.has(p.key)) return false; keys.add(p.key); return true;
  }).slice(0, 5).map(p => ({ key: clean(p.key, 30), label: clean(p.label, 50), dataUrl: p.dataUrl, quality: clean(p.quality, 80), createdAt: now() }));
}
function makeLead(payload, existing = {}) {
  const photos = normalizePhotos(payload.photos);
  return {
    ...existing,
    updatedAt: now(),
    name: clean(payload.name, 100), phone: phone(payload.phone), age: clean(payload.age, 3), city: clean(payload.city, 80),
    hairLossTime: clean(payload.hairLossTime, 120), pattern: clean(payload.pattern, 100), previousTreatment: clean(payload.previousTreatment, 250),
    symptoms: clean(payload.symptoms, 250), surgeryHistory: clean(payload.surgeryHistory, 250), consent: Boolean(payload.consent),
    photos: photos.length ? photos : (existing.photos || []), photoCount: photos.length ? photos.length : (existing.photoCount || 0)
  };
}

async function handleAPI(req, res, url) {
  const method = req.method;
  const parts = url.pathname.split('/').filter(Boolean);
  if (method === 'POST' && url.pathname === '/api/login') {
    const body = await parseBody(req, 10000);
    const given = String(body.password || '');
    if (!crypto.timingSafeEqual(Buffer.from(given.padEnd(64).slice(0,64)), Buffer.from(ADMIN_PASSWORD.padEnd(64).slice(0,64)))) return json(res, 401, { error: 'Clave incorrecta.' });
    const token = uid(24); sessions.set(token, { expiresAt: Date.now() + 1000 * 60 * 60 * 12 });
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Set-Cookie': `estecapelli_session=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=43200` });
    return res.end(JSON.stringify({ ok: true, demoPassword: IS_DEMO_PASSWORD }));
  }
  if (method === 'POST' && url.pathname === '/api/logout') {
    const token = cookies(req).estecapelli_session; if (token) sessions.delete(token);
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Set-Cookie': 'estecapelli_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0' }); return res.end('{"ok":true}');
  }
  if (method === 'GET' && url.pathname === '/api/me') return json(res, 200, { authenticated: authorized(req), demoPassword: IS_DEMO_PASSWORD });

  // Patient routes use an opaque link token; no admin session is required.
  if (parts[1] === 'patient' && parts[2]) {
    const db = readDB(); const lead = db.leads.find(l => l.token === parts[2]);
    if (!lead) return json(res, 404, { error: 'Este enlace ya no está disponible.' });
    if (method === 'GET') return json(res, 200, { lead: leadSummary(lead) });
    if (method === 'PUT') {
      const body = await parseBody(req); const updated = makeLead(body, lead);
      if (!updated.consent || !updated.name || !updated.phone) return json(res, 422, { error: 'Completa tu nombre, teléfono y consentimiento.' });
      if (updated.photos.length < 5) updated.status = 'incompleto'; else if (updated.status === 'nuevo' || updated.status === 'incompleto') updated.status = 'listo';
      Object.assign(lead, updated); writeDB(db); return json(res, 200, { ok: true, lead: leadSummary(lead) });
    }
  }
  if (method === 'POST' && url.pathname === '/api/patient') {
    const body = await parseBody(req); const lead = makeLead(body, { id: uid(), token: uid(), createdAt: now(), status: 'nuevo', notes: '', norwood: '' });
    if (!lead.consent || !lead.name || !lead.phone) return json(res, 422, { error: 'Completa tu nombre, teléfono y consentimiento.' });
    lead.status = lead.photos.length < 5 ? 'incompleto' : 'listo';
    const db = readDB(); db.leads.unshift(lead); writeDB(db); return json(res, 201, { ok: true, lead: leadSummary(lead) });
  }

  if (!requireAuth(req, res)) return;
  const db = readDB();
  if (method === 'GET' && url.pathname === '/api/leads') {
    const status = clean(url.searchParams.get('status'), 30);
    const search = clean(url.searchParams.get('search'), 120).toLowerCase();
    let leads = db.leads.map(leadSummary);
    if (status && status !== 'todos') leads = leads.filter(l => l.status === status);
    if (search) leads = leads.filter(l => `${l.name} ${l.phone} ${l.city}`.toLowerCase().includes(search));
    return json(res, 200, { leads });
  }
  if (method === 'GET' && url.pathname === '/api/stats') {
    const counts = db.leads.reduce((a, l) => { a[l.status || 'nuevo'] = (a[l.status || 'nuevo'] || 0) + 1; return a; }, {});
    return json(res, 200, { total: db.leads.length, counts });
  }
  if (method === 'POST' && url.pathname === '/api/invitations') {
    const body = await parseBody(req, 10000); const lead = { id: uid(), token: uid(), createdAt: now(), updatedAt: now(), name: clean(body.name,100), phone: phone(body.phone), age:'', city:'', hairLossTime:'', pattern:'', previousTreatment:'', symptoms:'', surgeryHistory:'', consent:false, photos:[], photoCount:0, status:'nuevo', notes:'', norwood:'' };
    db.leads.unshift(lead); writeDB(db); return json(res, 201, { ok:true, lead: leadSummary(lead), link: `${url.origin}/?token=${lead.token}` });
  }
  if (parts[1] === 'leads' && parts[2]) {
    const lead = db.leads.find(l => l.id === parts[2]); if (!lead) return json(res, 404, { error:'Caso no encontrado.' });
    if (method === 'GET') return json(res, 200, { lead });
    if (method === 'PATCH') {
      const body = await parseBody(req, 10000);
      const allowedStatuses = ['nuevo','incompleto','listo','contactar','agendado','cerrado'];
      if (body.status && allowedStatuses.includes(body.status)) lead.status = body.status;
      if (body.notes !== undefined) lead.notes = clean(body.notes, 1200);
      if (body.norwood !== undefined) lead.norwood = clean(body.norwood, 20);
      if (body.appointmentAt !== undefined) lead.appointmentAt = clean(body.appointmentAt, 40);
      lead.updatedAt = now(); writeDB(db); return json(res, 200, { ok:true, lead });
    }
  }
  return json(res, 404, { error:'Ruta no encontrada.' });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  try {
    if (url.pathname.startsWith('/api/')) return handleAPI(req, res, url);
    if (req.method === 'GET') return html(res);
    json(res, 405, { error:'Método no permitido.' });
  } catch (err) { console.error(err); json(res, 400, { error: err.message || 'No se pudo procesar la solicitud.' }); }
});
server.listen(PORT, '0.0.0.0', () => console.log(`Estecapelli PWA lista en http://0.0.0.0:${PORT}`));

const APP_HTML = String.raw`<!doctype html>
<html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#0b1f33"><title>Estecapelli · Preevaluación capilar</title>
<style>
:root{--ink:#0b1f33;--muted:#64748b;--bg:#f4f7fa;--line:#dbe4ec;--white:#fff;--teal:#00a9a5;--green:#25d366;--amber:#f4b942;--blue:#3d8dff;--red:#e86b6b;--shadow:0 16px 44px rgba(11,31,51,.12)}*{box-sizing:border-box}body{margin:0;font-family:Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;color:var(--ink);background:var(--bg)}button,input,select,textarea{font:inherit}button{cursor:pointer;border:0}.hidden{display:none!important}.shell{max-width:1180px;margin:auto;padding:18px}.top{display:flex;align-items:center;justify-content:space-between;gap:12px}.brand{display:flex;align-items:center;gap:10px;font-weight:800}.mark{width:32px;height:32px;border-radius:50%;display:grid;place-items:center;background:var(--teal);color:white;font-size:15px}.subtle{font-size:13px;color:var(--muted)}.hero{background:var(--ink);color:#fff;padding:28px;border-radius:24px;margin:22px 0;overflow:hidden;position:relative}.hero:after{content:"";width:260px;height:260px;border:42px solid rgba(0,169,165,.2);border-radius:50%;position:absolute;right:-65px;top:-105px}.hero>*{position:relative;z-index:1}.hero h1{max-width:630px;margin:8px 0 10px;font-size:clamp(31px,5vw,52px);line-height:1.02}.hero p{max-width:580px;margin:0;color:#c9d5e1;font-size:18px}.eyebrow{font-size:12px;font-weight:800;letter-spacing:.08em;color:var(--teal);text-transform:uppercase}.card{background:var(--white);border:1px solid var(--line);border-radius:18px;padding:20px;box-shadow:0 4px 16px rgba(15,23,42,.03)}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:14px}.step{padding:18px}.num{display:grid;place-items:center;width:34px;height:34px;background:#e2f7f6;border-radius:50%;color:#007e7a;font-weight:800;margin-bottom:16px}.step h3{margin:0 0 6px;font-size:17px}.step p{margin:0;color:var(--muted);font-size:14px}.button{display:inline-flex;align-items:center;justify-content:center;gap:8px;background:var(--teal);color:#fff;padding:13px 18px;border-radius:11px;font-weight:800}.button:hover{filter:brightness(.96)}.button.secondary{background:#e5f7f6;color:#007e7a}.button.dark{background:var(--ink)}.button.ghost{background:transparent;color:var(--ink);border:1px solid var(--line)}.notice{padding:13px 15px;border-radius:12px;background:#fff4dc;color:#6b4b00;font-size:14px}.error{padding:12px 14px;border-radius:10px;background:#fff0f0;color:#a12929;font-size:14px}.success{padding:13px 15px;border-radius:12px;background:#e6f8f5;color:#006b67}.field{display:grid;gap:7px}.field label{font-size:14px;font-weight:750}.field input,.field select,.field textarea{width:100%;padding:13px;border:1px solid var(--line);border-radius:11px;background:#fff;color:var(--ink);outline:none}.field input:focus,.field select:focus,.field textarea:focus{border-color:var(--teal);box-shadow:0 0 0 3px rgba(0,169,165,.12)}.field textarea{resize:vertical;min-height:100px}.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}.wide{grid-column:1/-1}.patient-wrap{max-width:580px;margin:auto;padding:22px 16px 44px}.patient-top{display:flex;justify-content:space-between;align-items:center;margin-bottom:24px}.progress{height:7px;background:#e4ebf1;border-radius:99px;overflow:hidden;margin:14px 0 26px}.progress span{display:block;height:100%;background:var(--teal);border-radius:99px}.question-card{padding:22px}.question-card h1{font-size:29px;line-height:1.1;margin:10px 0}.question-card p{color:var(--muted);line-height:1.55}.choice{display:flex;gap:11px;padding:13px;border:1px solid var(--line);border-radius:12px;margin:10px 0;align-items:flex-start}.choice input{margin-top:4px;accent-color:var(--teal)}.actions{display:flex;justify-content:space-between;gap:12px;margin-top:22px}.photo-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}.photo-slot{border:1.5px dashed #bad0d2;border-radius:14px;min-height:162px;padding:12px;background:#fbffff;position:relative;display:flex;flex-direction:column;justify-content:space-between;gap:8px}.photo-slot strong{font-size:14px}.photo-slot small{color:var(--muted)}.photo-slot input{display:none}.photo-add{display:grid;place-items:center;min-height:92px;border-radius:10px;background:#e5f7f6;color:#00847f;font-weight:800;font-size:14px;text-align:center;padding:8px}.photo-preview{width:100%;height:92px;border-radius:10px;object-fit:cover}.quality{font-size:11px;color:#007e7a}.patient-note{font-size:12px;color:var(--muted);text-align:center;margin-top:16px;line-height:1.5}.login{max-width:420px;margin:10vh auto;padding:20px}.login h1{font-size:32px;margin:12px 0}.admin{max-width:1280px;margin:auto;padding:22px}.admin-header{display:flex;align-items:center;justify-content:space-between;gap:14px;margin-bottom:22px}.admin-header h1{margin:4px 0 0;font-size:30px}.metric-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}.metric{padding:16px}.metric b{display:block;font-size:29px;margin-top:7px}.metric span{color:var(--muted);font-size:13px}.toolbar{display:flex;align-items:center;justify-content:space-between;gap:10px;margin:22px 0 12px;flex-wrap:wrap}.filters{display:flex;gap:8px;flex-wrap:wrap}.filter{padding:8px 11px;border-radius:99px;background:#fff;color:var(--muted);border:1px solid var(--line);font-weight:700;font-size:13px}.filter.active{background:var(--ink);color:white;border-color:var(--ink)}.search{min-width:230px;padding:10px 12px;border:1px solid var(--line);border-radius:10px}.lead-list{display:grid;gap:10px}.lead{display:grid;grid-template-columns:42px minmax(160px,1.2fr) minmax(140px,1.4fr) 130px 140px;align-items:center;gap:14px;padding:14px 16px}.avatar{width:38px;height:38px;border-radius:50%;display:grid;place-items:center;background:#e0f6f5;color:#00847f;font-weight:850}.lead-name{font-weight:800}.lead-meta{font-size:13px;color:var(--muted);margin-top:3px}.tag{display:inline-flex;align-items:center;justify-content:center;border-radius:99px;padding:7px 10px;font-size:12px;font-weight:800}.tag.nuevo{background:#e8f0ff;color:#2c64bd}.tag.incompleto{background:#fff3dc;color:#966000}.tag.listo{background:#e2f7f6;color:#007e7a}.tag.contactar{background:#efe8ff;color:#7150aa}.tag.agendado{background:#e8f6e8;color:#27723a}.tag.cerrado{background:#edf0f4;color:#64748b}.icon-btn{width:38px;height:38px;border-radius:10px;background:#eff5f7;color:var(--ink);font-size:18px}.empty{text-align:center;padding:50px;color:var(--muted)}.modal-backdrop{position:fixed;inset:0;background:rgba(11,31,51,.55);z-index:10;display:flex;justify-content:flex-end}.drawer{background:#fff;width:min(680px,100%);height:100%;overflow:auto;padding:24px}.drawer-head{display:flex;justify-content:space-between;gap:12px;align-items:flex-start}.drawer h2{margin:4px 0;font-size:28px}.detail-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:12px;margin:22px 0}.detail{padding:12px;border-radius:12px;background:var(--bg)}.detail span{font-size:11px;font-weight:800;color:var(--muted);text-transform:uppercase;letter-spacing:.06em}.detail b{display:block;margin-top:5px;font-size:14px}.thumbs{display:grid;grid-template-columns:repeat(3,1fr);gap:9px}.thumb{border-radius:10px;overflow:hidden;background:#eef3f7;aspect-ratio:1;display:flex;align-items:end;padding:7px;color:#fff;font-size:11px;font-weight:800;background-size:cover;background-position:center}.thumb.none{color:var(--muted);align-items:center;justify-content:center;background:#f0f4f7}.invite-row{display:flex;gap:10px;align-items:end;margin-bottom:18px}.invite-row .field{flex:1}@media(max-width:720px){.shell{padding:14px}.grid,.metric-grid{grid-template-columns:1fr}.hero{padding:24px}.form-grid{grid-template-columns:1fr}.wide{grid-column:auto}.lead{grid-template-columns:42px 1fr auto}.lead>.hide-mobile{display:none}.toolbar{align-items:stretch}.search{width:100%}.invite-row{display:grid;grid-template-columns:1fr}.detail-grid{grid-template-columns:1fr}.photo-grid{grid-template-columns:1fr 1fr}.admin{padding:16px}.top .subtle{display:none}}
</style></head><body><div id="app"></div>
<script>
const app=document.getElementById('app'); const params=new URLSearchParams(location.search); let state={lead:null,photos:{},patientStep:1,adminFilter:'todos',adminLeads:[]};
const photoSpecs=[['frontal','Vista frontal','Centra la línea de cabello'],['vertex','Vértex','Inclina levemente la cabeza'],['temporalRight','Temporal derecha','Muestra la entrada derecha'],['temporalLeft','Temporal izquierda','Muestra la entrada izquierda'],['donor','Zona donante','Fotografía posterior']];
const escapeHtml=s=>String(s||'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#039;','"':'&quot;'}[c]));
async function api(url,options={}){const r=await fetch(url,{headers:{'Content-Type':'application/json',...(options.headers||{})},...options});const data=await r.json().catch(()=>({}));if(!r.ok)throw new Error(data.error||'No fue posible completar la acción.');return data}
function logo(){return '<div class="brand"><span class="mark">E</span><span>Estecapelli</span></div>'}
function patientShell(content){app.innerHTML='<main class="patient-wrap"><div class="patient-top">'+logo()+'<span class="subtle">Preevaluación capilar</span></div>'+content+'</main>'}
function statusName(s){return ({nuevo:'Nuevo',incompleto:'Incompleto',listo:'Listo para revisión',contactar:'Contactar',agendado:'Agendado',cerrado:'Cerrado'}[s]||'Nuevo')}
function patientIntro(){state.patientStep=1;patientShell('<div class="card question-card"><span class="eyebrow">4–6 minutos</span><h1>Comienza tu evaluación capilar.</h1><p>Te pediremos antecedentes básicos y fotografías guiadas. El equipo revisará la información antes de contactarte.</p><div class="progress"><span style="width:33%"></span></div><div class="notice">Esta preevaluación no reemplaza una consulta médica ni entrega un diagnóstico.</div><div class="actions"><span></span><button class="button" id="start">Comenzar</button></div></div><p class="patient-note">Tus fotografías no se envían por WhatsApp. Se cargan directamente en este formulario.</p>');document.getElementById('start').onclick=patientData}
function patientData(){state.patientStep=2;const l=state.lead||{};patientShell('<div class="card question-card"><span class="eyebrow">Paso 1 de 3</span><h1>Cuéntanos un poco sobre ti.</h1><p>Usaremos estos datos para revisar tu solicitud y coordinar contacto.</p><div class="progress"><span style="width:55%"></span></div><form id="dataForm"><div class="form-grid"><div class="field wide"><label>Nombre completo</label><input required name="name" value="'+escapeHtml(l.name||'')+'" placeholder="Ej. Juan Pérez"></div><div class="field"><label>Teléfono con WhatsApp</label><input required name="phone" value="'+escapeHtml(l.phone||'')+'" inputmode="tel" placeholder="+56 9..."></div><div class="field"><label>Edad</label><input name="age" value="'+escapeHtml(l.age||'')+'" inputmode="numeric" min="18" max="99" placeholder="Ej. 36"></div><div class="field"><label>Comuna / ciudad</label><input name="city" value="'+escapeHtml(l.city||'')+'" placeholder="Ej. Providencia"></div><div class="field"><label>Tiempo de evolución</label><select name="hairLossTime"><option value="">Selecciona</option>'+['Menos de 1 año','1–3 años','3–5 años','Más de 5 años'].map(x=>'<option '+(l.hairLossTime===x?'selected':'')+'>'+x+'</option>').join('')+'</select></div><div class="field wide"><label>¿Dónde percibes principalmente la pérdida?</label><select name="pattern"><option value="">Selecciona</option>'+['Entradas / línea frontal','Vértex o coronilla','Zona frontal y vértex','Caída difusa','Otro / no estoy seguro'].map(x=>'<option '+(l.pattern===x?'selected':'')+'>'+x+'</option>').join('')+'</select></div><div class="field wide"><label>Tratamientos previos o actuales <span class="subtle">(opcional)</span></label><input name="previousTreatment" value="'+escapeHtml(l.previousTreatment||'')+'" placeholder="Ej. minoxidil, finasteride, PRP"></div><div class="field wide"><label>¿Presentas dolor, ardor, lesiones, caída en placas o descamación importante? <span class="subtle">(opcional)</span></label><input name="symptoms" value="'+escapeHtml(l.symptoms||'')+'" placeholder="Describe brevemente o escribe “No”"></div></div><label class="choice"><input required type="checkbox" name="consent" '+(l.consent?'checked':'')+'><span>Autorizo el uso de mis antecedentes e imágenes exclusivamente para coordinar y revisar esta preevaluación. Entiendo que no corresponde a un diagnóstico ni reemplaza una consulta médica.</span></label><div id="formError"></div><div class="actions"><button type="button" class="button ghost" id="back">Volver</button><button class="button">Continuar a fotografías</button></div></form></div>');document.getElementById('back').onclick=patientIntro;document.getElementById('dataForm').onsubmit=e=>{e.preventDefault();const d=Object.fromEntries(new FormData(e.target));d.consent=!!d.consent;state.lead={...state.lead,...d};patientPhotos()}}
function patientPhotos(){state.patientStep=3; const cards=photoSpecs.map(([k,t,h])=>{const p=state.photos[k];return '<label class="photo-slot" for="photo-'+k+'"><strong>'+t+'</strong><small>'+h+'</small>'+(p?'<img class="photo-preview" src="'+p.dataUrl+'"><span class="quality">✓ imagen cargada</span>':'<span class="photo-add">Tomar o subir foto<br>⌾</span>')+'<input id="photo-'+k+'" accept="image/*" capture="environment" type="file"></label>'}).join('');patientShell('<div class="card question-card"><span class="eyebrow">Paso 2 de 3</span><h1>Realiza tu estudio fotográfico.</h1><p>Busca buena luz, evita filtros y procura que cada zona quede claramente visible.</p><div class="progress"><span style="width:82%"></span></div><div class="photo-grid">'+cards+'</div><div id="photoError" style="margin-top:12px"></div><div class="actions"><button class="button ghost" id="back">Volver</button><button class="button" id="finish">Enviar para revisión</button></div></div><p class="patient-note">Control técnico: verificaremos que estén las cinco vistas solicitadas. Un profesional realizará la revisión posterior.</p>');photoSpecs.forEach(([k])=>document.getElementById('photo-'+k).onchange=e=>readPhoto(e.target.files[0],k));document.getElementById('back').onclick=patientData;document.getElementById('finish').onclick=submitPatient}
function readPhoto(file,key){if(!file)return;if(!file.type.startsWith('image/'))return show('photoError','Selecciona una fotografía válida.');compress(file).then(dataUrl=>{state.photos[key]={key,label:photoSpecs.find(x=>x[0]===key)[1],dataUrl,quality:'Control técnico pendiente'};patientPhotos()}).catch(()=>show('photoError','No fue posible procesar esta fotografía. Intenta nuevamente.'))}
function compress(file){return new Promise((resolve,reject)=>{const r=new FileReader();r.onerror=reject;r.onload=()=>{const img=new Image();img.onerror=reject;img.onload=()=>{const max=1400;const scale=Math.min(1,max/Math.max(img.width,img.height));const c=document.createElement('canvas');c.width=Math.round(img.width*scale);c.height=Math.round(img.height*scale);c.getContext('2d').drawImage(img,0,0,c.width,c.height);resolve(c.toDataURL('image/jpeg',.72))};img.src=r.result};r.readAsDataURL(file)})}
function show(id,msg,type='error'){const el=document.getElementById(id);if(el)el.innerHTML='<div class="'+type+'">'+escapeHtml(msg)+'</div>'}
async function submitPatient(){const photos=Object.values(state.photos);if(photos.length<5)return show('photoError','Aún faltan '+(5-photos.length)+' fotografías. Completa las cinco vistas para enviar.');const payload={...state.lead,photos};try{const result=state.lead&&state.lead.token?await api('/api/patient/'+state.lead.token,{method:'PUT',body:JSON.stringify(payload)}):await api('/api/patient',{method:'POST',body:JSON.stringify(payload)});state.lead=result.lead;patientShell('<div class="card question-card"><span class="eyebrow">Solicitud enviada</span><h1>Tu preevaluación está lista para revisión.</h1><p>Recibimos tus antecedentes y estudio fotográfico. Nuestro equipo se pondrá en contacto contigo para coordinar el siguiente paso.</p><div class="success">✓ Fotografías recibidas · Estado: '+escapeHtml(statusName(result.lead.status))+'</div><div class="actions"><span></span><button class="button" onclick="location.href='/'">Finalizar</button></div></div><p class="patient-note">No envíes fotografías adicionales por WhatsApp a menos que el equipo te las solicite.</p>')}catch(err){show('photoError',err.message)}}
async function loadPatient(){const token=params.get('token');if(token){try{const r=await api('/api/patient/'+token);state.lead=r.lead;return patientIntro()}catch(err){return patientShell('<div class="card question-card"><h1>Este enlace no está disponible.</h1><p>'+escapeHtml(err.message)+'</p><a class="button" href="/?patient=1">Iniciar una nueva solicitud</a></div>')}}patientIntro()}
function login(){app.innerHTML='<main class="login"><div class="card"><div class="top">'+logo()+'<span class="subtle">Panel interno</span></div><h1>Acceso del equipo</h1><p class="subtle">Ingresa con la clave definida en Replit Secrets.</p><form id="loginForm"><div class="field"><label>Clave de acceso</label><input type="password" name="password" required autofocus placeholder="••••••••••"></div><div id="loginError" style="margin-top:12px"></div><button class="button dark" style="width:100%;margin-top:16px">Entrar al panel</button></form><p class="patient-note">El acceso administrativo está separado del enlace del paciente.</p></div></main>';document.getElementById('loginForm').onsubmit=async e=>{e.preventDefault();try{await api('/api/login',{method:'POST',body:JSON.stringify({password:new FormData(e.target).get('password')})});admin()}catch(err){show('loginError',err.message)}}}
async function admin(){const me=await api('/api/me');if(!me.authenticated)return login();app.innerHTML='<main class="admin"><div class="admin-header"><div>'+logo()+'<h1>Preevaluaciones capilares</h1><span class="subtle">Estecapelli · panel operativo</span></div><div><button class="button ghost" id="logout">Salir</button></div></div>'+(me.demoPassword?'<div class="notice">Estás usando la clave de demostración. Antes de compartir el acceso, crea ADMIN_PASSWORD en Replit Secrets.</div>':'')+'<section id="metrics" class="metric-grid" style="margin-top:18px"></section><section class="card" style="margin-top:20px"><div class="top"><div><span class="eyebrow">Nueva invitación</span><h2 style="margin:5px 0 0;font-size:22px">Envía un enlace individual por WhatsApp</h2></div></div><div class="invite-row"><div class="field"><label>Nombre del paciente <span class="subtle">(opcional)</span></label><input id="inviteName" placeholder="Ej. Andrea López"></div><div class="field"><label>Teléfono WhatsApp</label><input id="invitePhone" placeholder="+56 9..."></div><button class="button" id="invite">Crear enlace</button></div><div id="inviteResult"></div></section><div class="toolbar"><div class="filters" id="filters"></div><input class="search" id="search" placeholder="Buscar nombre, teléfono o comuna"></div><section id="leadList" class="lead-list"></section></main>';document.getElementById('logout').onclick=async()=>{await api('/api/logout',{method:'POST'});login()};document.getElementById('invite').onclick=createInvitation;document.getElementById('search').oninput=renderLeads;await refreshAdmin()}
async function refreshAdmin(){const [stats,leads]=await Promise.all([api('/api/stats'),api('/api/leads')]);state.stats=stats;state.adminLeads=leads.leads;renderMetrics();renderFilters();renderLeads()}
function renderMetrics(){const c=state.stats.counts||{};document.getElementById('metrics').innerHTML=[['Total',state.stats.total],['Nuevos',c.nuevo||0],['Por completar',c.incompleto||0],['Listos / agenda',(c.listo||0)+(c.agendado||0)]].map(([l,n])=>'<div class="card metric"><span>'+l+'</span><b>'+n+'</b></div>').join('')}
function renderFilters(){const filters=['todos','nuevo','incompleto','listo','contactar','agendado'];document.getElementById('filters').innerHTML=filters.map(f=>'<button class="filter '+(state.adminFilter===f?'active':'')+'" data-filter="'+f+'">'+(f==='todos'?'Todos':statusName(f))+'</button>').join('');document.querySelectorAll('[data-filter]').forEach(b=>b.onclick=()=>{state.adminFilter=b.dataset.filter;renderFilters();renderLeads()})}
function renderLeads(){const q=(document.getElementById('search')?.value||'').toLowerCase();let leads=state.adminLeads.filter(l=>(state.adminFilter==='todos'||l.status===state.adminFilter)&&((l.name||'')+' '+(l.phone||'')+' '+(l.city||'')).toLowerCase().includes(q));const list=document.getElementById('leadList');if(!leads.length){list.innerHTML='<div class="card empty">No hay preevaluaciones en esta vista.</div>';return}list.innerHTML=leads.map(l=>'<article class="card lead"><div class="avatar">'+escapeHtml((l.name||'?').charAt(0).toUpperCase())+'</div><div><div class="lead-name">'+escapeHtml(l.name||'Sin nombre')+'</div><div class="lead-meta">'+escapeHtml(l.city||'Sin comuna')+' · '+escapeHtml(l.phone||'Sin teléfono')+'</div></div><div class="hide-mobile"><span class="subtle">'+(l.photoCount||0)+'/5 fotos</span><div class="lead-meta">'+escapeHtml(l.hairLossTime||'Sin antecedentes')+'</div></div><div class="hide-mobile"><span class="tag '+escapeHtml(l.status)+'">'+escapeHtml(statusName(l.status))+'</span></div><button class="icon-btn" data-lead="'+l.id+'" title="Abrir caso">›</button></article>').join('');document.querySelectorAll('[data-lead]').forEach(b=>b.onclick=()=>openLead(b.dataset.lead))}
async function createInvitation(){const phone=document.getElementById('invitePhone').value.trim();const name=document.getElementById('inviteName').value.trim();if(!phone)return show('inviteResult','Ingresa el teléfono para crear una invitación.');try{const r=await api('/api/invitations',{method:'POST',body:JSON.stringify({name,phone})});const text=encodeURIComponent('Hola '+(name||'')+', para avanzar con tu evaluación capilar completa, por favor utiliza este enlace seguro: '+r.link);document.getElementById('inviteResult').innerHTML='<div class="success">Enlace creado. <a href="'+escapeHtml(r.link)+'" target="_blank">Abrir formulario</a> · <a href="https://wa.me/'+escapeHtml(phone.replace(/\D/g,''))+'?text='+text+'" target="_blank">Enviar por WhatsApp</a></div>';document.getElementById('inviteName').value='';document.getElementById('invitePhone').value='';await refreshAdmin()}catch(err){show('inviteResult',err.message)}}
async function openLead(id){try{const r=await api('/api/leads/'+id);const l=r.lead;const photos=(l.photos||[]).length?(l.photos||[]).map(p=>'<div class="thumb" style="background-image:url(\''+p.dataUrl+'\')">'+escapeHtml(p.label)+'</div>').join(''):'<div class="thumb none">Sin fotografías cargadas</div>';const modal=document.createElement('div');modal.className='modal-backdrop';modal.id='modal';modal.innerHTML='<aside class="drawer"><div class="drawer-head"><div><span class="eyebrow">Caso '+escapeHtml(statusName(l.status))+'</span><h2>'+escapeHtml(l.name||'Sin nombre')+'</h2><span class="subtle">'+escapeHtml(l.phone||'')+' · '+escapeHtml(l.city||'')+'</span></div><button class="icon-btn" id="closeModal">×</button></div><div class="detail-grid"><div class="detail"><span>Edad</span><b>'+escapeHtml(l.age||'No informado')+'</b></div><div class="detail"><span>Tiempo de evolución</span><b>'+escapeHtml(l.hairLossTime||'No informado')+'</b></div><div class="detail"><span>Patrón referido</span><b>'+escapeHtml(l.pattern||'No informado')+'</b></div><div class="detail"><span>Tratamientos</span><b>'+escapeHtml(l.previousTreatment||'No informado')+'</b></div></div><h3>Estudio fotográfico</h3><div class="thumbs">'+photos+'</div><div class="field" style="margin-top:22px"><label>Estado operativo</label><select id="leadStatus">'+['nuevo','incompleto','listo','contactar','agendado','cerrado'].map(s=>'<option value="'+s+'" '+(l.status===s?'selected':'')+'>'+statusName(s)+'</option>').join('')+'</select></div><div class="form-grid" style="margin-top:12px"><div class="field"><label>Norwood <span class="subtle">(uso interno)</span></label><select id="norwood"><option value="">Sin clasificar</option>'+['I','II','IIA','III','III-V','IIIA','IV','IVA','V','VA','VI','VII','No concluyente'].map(n=>'<option '+(l.norwood===n?'selected':'')+'>'+n+'</option>').join('')+'</select></div><div class="field"><label>Fecha de consulta <span class="subtle">(opcional)</span></label><input id="appointmentAt" type="datetime-local" value="'+escapeHtml(l.appointmentAt||'')+'"></div></div><div class="field" style="margin-top:12px"><label>Notas internas</label><textarea id="leadNotes" placeholder="Observaciones para el equipo">'+escapeHtml(l.notes||'')+'</textarea></div><div id="detailMessage" style="margin-top:12px"></div><div class="actions"><a class="button secondary" target="_blank" href="https://wa.me/'+escapeHtml((l.phone||'').replace(/\D/g,''))+'?text='+encodeURIComponent('Hola '+(l.name||'')+', revisamos tu preevaluación. Te contactamos para coordinar el siguiente paso.')+'">WhatsApp</a><button class="button" id="saveLead">Guardar cambios</button></div><p class="patient-note">La etiqueta Norwood es interna y no corresponde a un diagnóstico comunicado al paciente.</p></aside>';document.body.appendChild(modal);document.getElementById('closeModal').onclick=()=>modal.remove();modal.onclick=e=>{if(e.target===modal)modal.remove()};document.getElementById('saveLead').onclick=async()=>{try{await api('/api/leads/'+l.id,{method:'PATCH',body:JSON.stringify({status:document.getElementById('leadStatus').value,norwood:document.getElementById('norwood').value,notes:document.getElementById('leadNotes').value,appointmentAt:document.getElementById('appointmentAt').value})});show('detailMessage','Cambios guardados.','success');await refreshAdmin()}catch(err){show('detailMessage',err.message)}}}catch(err){alert(err.message)}}
async function start(){if(params.has('admin'))return admin();if(params.has('patient')||params.has('token'))return loadPatient();const me=await api('/api/me');app.innerHTML='<main class="shell"><div class="top">'+logo()+'<button class="button ghost" id="adminLink">Equipo</button></div><section class="hero"><span class="eyebrow">PWA de preevaluación capilar</span><h1>Ordena la evaluación antes de la consulta.</h1><p>Un flujo móvil simple para datos, consentimiento y fotografías guiadas, abierto directamente desde WhatsApp.</p><div style="margin-top:22px"><button class="button" id="patientLink">Iniciar preevaluación</button></div></section><section class="grid"><article class="card step"><div class="num">1</div><h3>Datos claros</h3><p>La persona completa la información mínima desde su teléfono.</p></article><article class="card step"><div class="num">2</div><h3>Fotos guiadas</h3><p>La app solicita las cinco vistas necesarias para revisión.</p></article><article class="card step"><div class="num">3</div><h3>Contacto mejor preparado</h3><p>El equipo recibe casos ordenados antes de agendar.</p></article></section><p class="patient-note">La información se revisa por el equipo. Esta plataforma no entrega diagnósticos automáticos.</p></main>';document.getElementById('patientLink').onclick=()=>location.href='/?patient=1';document.getElementById('adminLink').onclick=()=>location.href='/?admin=1'}start();
</script></body></html>`;
